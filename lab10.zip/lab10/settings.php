<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s104222099";
	$pwd = "140204";
	$sql_db = "s104222099_db";
?>
