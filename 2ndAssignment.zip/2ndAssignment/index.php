<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
  <meta charset="utf-8" >
  <meta name="description" content="Index page" >
  <meta name="keywords"    content="Assignment Part 2, COS10026" >
  <meta name="author"      content="Huu Nhan Le (104171133)" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body id="homepage">
	<?php 
        require_once "header.inc";
        require_once "footer.inc";
    ?>

    <main>
        <figure id="Assignvid">
            <embed src="https://www.youtube.com/embed/mdotNRRKfmw">
			<embed src="https://www.youtube.com/embed/mdotNRRKfmw">
        </figure>
		<figure id="Assigncap">
			<figcaption><p><strong>Assignment 1 Video</strong></p></figcaption>
			<figcaption><p><strong>Assignment 2 Video</strong></p></figcaption>
		</figure>
        <h1>'Love and Responsibility'</h1>
        <h3>Welcome to MeArt</h3>
    </main>
    
</body>
