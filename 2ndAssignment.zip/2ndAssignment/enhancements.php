<!DOCTYPE html>
<html lang="en">
<head>
  <title>Enhancements Assignment Part 1</title>
  <meta charset="utf-8" >
  <meta name="description" content="Enhancements page" >
  <meta name="keywords"    content="Assignment 1, COS10026" >
  <meta name="author"      content="Multiple authors" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body >
    <?php 
        require_once "header.inc";
        require_once "footer.inc";
    ?>
   
    <main>

      <div id="header">
        <h1>Enhancement for Assignment Part 1</h1>
      </div>

      <div class="row">
        <div class="leftcolumn">
          <div class="card">
            <h2>Flexbox</h2>
            <h5>HTML</h5>
            <div class="fakeimg" style="height:200px;"><img src="images/flex.webp" alt="Image"></div>
            <p class="card">We use "display: flex" for navigation bars and other elements to set theirs flexible length.</p>
          </div>
          <br>

          <div class="card">
            <h2>Justify-content</h2>
            <h5>CSS</h5>
            <div class="fakeimg" style="height:200px;"><img src="images/justtify.png" alt="Iamge"></div>
            <p class="card">We use "Justify-content" to align many items like block, flexbox, etc.</p>
          </div>
          <br>

          <div id="transition_button">
            <a href="enhancements2.php">Click here to go to Enhancement Assignment 2</a>
          </div>
        </div>
      </div>  

      <div>
        <h4>References</h4>
        <a href="https://viblo.asia/p/css-flexible-box-flexbox-day-du-nhat-Ljy5VDWoZra" class="reference">Flex image</a>
        <br>
        <a href="https://dirask.com/posts/CSS-justify-content-in-flexbox-flex-direction-column-DNbAJD"  class="reference">Justify image</a>
      </div>

      
    </main> 
</body>
</html>