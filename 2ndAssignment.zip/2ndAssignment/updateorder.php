<?php
include_once('settings.php');
$Database = mysqli_connect($host, $user, $pwd, $sql_db);

$order_id = $_POST["orderID"];
$getStatus = mysqli_fetch_assoc(mysqli_query($Database, " SELECT order_status FROM orders where order_id = '$order_id' "));
$status =  $_POST["updateStatus"];
$query = "UPDATE orders SET order_status = '$status' WHERE order_id = '$order_id'";

$result = mysqli_query($Database, $query);

header("location: manager.php");
exit;
