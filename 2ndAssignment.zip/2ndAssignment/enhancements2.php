<!DOCTYPE html>
<html lang="en">
<head>
  <title>Enhancements Part 2</title>
  <meta charset="utf-8" >
  <meta name="description" content="Enhancements page" >
  <meta name="keywords"    content="Assignment Part 2, COS10026" >
  <meta name="author"      content="Huu Nhan Le (104171133), Phan Le" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body >
    <?php 
        require_once "header.inc";
        require_once "footer.inc";
    ?>

    <main>
        <h1>Enhancements for Assignment Part 2</h1>
        
        <section class = "enhancements_box">
            <h2>First enhancements</h2>
            <br>
            <fieldset>
                <legend><h3>Description of enhancement</h3></legend>
                <p>For the first enhancement, I (Huu Nhan Le) try to store the all products' name, options and price in the 'products' table and then automatically fill the 'product.php' page with these data. The assignment only requires us to create a table for the information entered by the customers in the ‘payment.php’ page. However, through this enhancement, a separate table is created from the start to store all the information related to our service, saving the time and effort to remember and including them in the code. In addition, when the customer visits the ‘product.php’ page, they can view these details about the service and thus increase their experience on our website.</p>
                <br>
                <p>To implement this feature, I included in the ‘product.php’ code the code to connect to the general database (e.g. $conn, $mysqli_connect) and make query (e.g. $query, $mysqli_query). Then, I used ‘while’ loop and ‘array_push’ to transfer the results of the query into a variety of arrays. And on the sections for the information about the services, I only get those information out of the arrays and insert into the table via ‘table’, ‘th’, ‘td’ tags.</p>
            </fieldset>
            <br>
            <h4>Locations of implemented enhancements:</h4>
            <a href="product.php#decoration_art" >Table of services for decoration art subject</a>
            <br>
            <a href="product.php#pencil_drawing" >Table of services for pencil drawing subject</a>
        </section>

        <section class="enhancements_box">
            <h2>Second enhancement</h2>
            <br>
            <fieldset>
                <legend>
                    <h3>Description of enhancement</h3>
                </legend>
                <p>For the Second enhancement, I (Le Phan) seperated the customers info from the orders table and store them in a different table called customers, this change helps us in the long term to know who orders the most and give them discounts, more help and prioritise their orders to incentivise them to order more from us, this can also help in situations where the orders tables gets corrupted we won't lose our customers data</p>
                <br>
                <p>To implement this feature, I seperated the insert and create table query into two and use two different queries to insert/change data in our database</p>
            </fieldset>
            <br>
            <h4>Locations of implemented enhancements:</h4>
            <a href="process_order.php">My changes to the code to implement this feature</a>
        </section>

    </main>
</body>
</html>