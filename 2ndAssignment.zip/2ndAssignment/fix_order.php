<?php 
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Fix Order</title>
  <meta charset="utf-8" >
  <meta name="description" content="Fix order" >
  <meta name="keywords"    content="Assignment 2, COS10026" >
  <meta name="author"      content="Binh Ca Nguyen, Huu Nhan Le (104171133)" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body>
  <?php
    if (!isset($_SESSION["fnames"])) {
      header('location: payment.php');
      exit;
    }    

    require_once "header.inc";
    require_once "footer.inc";
    
    $errMsg = $_SESSION["Error"];
    
    $fnames = $_SESSION["fnames"];
    $lnames = $_SESSION["lnames"];
    $email = $_SESSION["email"];
    $str_addr = $_SESSION["str_addr"];
    $sub_town = $_SESSION["sub_town"];
    $state = $_SESSION["state"];
    $pcode = $_SESSION["pcode"];
    $phone = $_SESSION["phone"];
    $contact = $_SESSION["contact"]; 

    $Quantity = $_SESSION["Quantity"];
    $num_week= $_SESSION["num_week"];
    $Option = $_SESSION["Option"];
    $Product= $_SESSION["Product"];
    $comment = $_SESSION["comment"];

    $errList = array("fnames", "lnames","email","str_addr", "sub_town", "pcode", "phone", "CardName", "Card Expired!", "CardCVV", "Wrong Visa format", "Wrong Mastercard format", "Wrong AmericanExpress format");
    $errList_2 = array("no fnames data", "no lnames data", "no email data", "no str_addr data", "no sub_town data", "no state data", "no pcode data", "no phone data", "no Quantity data", "no num_week data", "no Option data", "no CardName data", "no CardNumber data", "no CardExpiryMonth data", "no CardExpiryYear data", "no CardCVV data");
  ?>
  
  <?php
    function generateStateOptions($state) {
      $states = array(
          'VIC' => 'VIC',
          'NSW' => 'NSW',
          'QLD' => 'QLD',
          'NT' => 'NT',
          'WA' => 'WA',
          'SA' => 'SA',
          'TAS' => 'TAS',
          'ACT' => 'ACT'
      );
  
      $options = "<option value=\"\" " . ($state == '' ? "selected='selected'" : '') . ">Please Select</option>";
      
      foreach ($states as $key => $value) {
          $options .= "<option value='{$key}' " . ($state == $key ? "selected='selected'" : '') . ">{$value}</option>";
      }
  
      return $options;
    }

    function generateQuantityOptions($selectedQuantity) {
      $options = "<option value=''>Please Select</option>";
      $quantities = array(1, 2, 3, 4, 5, 6, 7);
      
      foreach($quantities as $quantity) {
        $selected = ($selectedQuantity == $quantity) ? "selected='selected'" : "";
        $options .= "<option value='$quantity' $selected>$quantity</option>";
      }
      
      return $options;
    }

    function generateOptionOptions($selectedOption) {
      $options = "<option value=''>Please Select</option>";
      $option_arr = array(
        'day' => '8:00 AM - 11:00 AM',
        'night' => '6:00 PM - 9:00 PM',
      );
      
      foreach($option_arr as $option => $value) {
        $selected = ($selectedOption == $option) ? "selected='selected'" : "";
        $options .= "<option value='$option' $selected>$value</option>";
      }
      
      return $options;
    }

  ?>

  <?php 
    echo "<main>
      <form action='process_order.php' id='formB' method='post' novalidate>
        <fieldset id='mfield'>";

        if (strpos($errMsg, $errList_2[0]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter first name!</p>";  
        } else {
          if(strpos($errMsg, $errList[0]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong first name format!</p>";
          } else {
            $inputClass = "correct_input";
          }
        }
        echo  "<legend><h2> Please check your information</h2></legend> 
			<label for='fnames'>First Name</label>
			<input type='text' name='fnames' id='fnames' required='required' value='$fnames' class='$inputClass'>
			<br>";
      
        if (strpos($errMsg, $errList_2[1]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter last name!</p>";  
        } else {
          if(strpos($errMsg, $errList[1]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong last name format!</p>";
          } else {
            $inputClass = "correct_input";
          }
        }
        echo  "<label for='lnames'>Family Name</label>
			<input type='text' name='lnames' id='lnames' required='required' value='$lnames' class='$inputClass'>
			<br>";
      
        if (strpos($errMsg, $errList_2[2]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter email!</p>";  
        } else {
          if(strpos($errMsg, $errList[2]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong email format!</p>";
          } else {
            $inputClass = "correct_input";
          }
        }
        echo  "<label for='email'>Email</label>
			<input type='text' name='email' id='email' required='required' value='$email' class='$inputClass'>
			<br>
			<fieldset> 
			<legend><h2> Contact information </h2> </legend>";
      
      
        if (strpos($errMsg, $errList_2[3]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter street address!</p>";  
        } else {
          if(strpos($errMsg, $errList[3]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong street address format!</p>";
          } else {
            $inputClass = "correct_input";
          }
        }
        echo "<label for='str_addr'>Street address</label>
			<input type='text' name='str_addr' id='str_addr' required='required' value='$str_addr' class='$inputClass'>
			<br>";  
      
        if (strpos($errMsg, $errList_2[4]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter suburb!</p>";  
        } else {
          if(strpos($errMsg, $errList[4]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong suburb format!</p>";
          } else {
            $inputClass = "correct_input";
          }
        }
        echo "<label for='sub_town'>Suburb/Town</label>
			<input type='text' name='sub_town' id='sub_town' required='required' value='$sub_town' class='$inputClass'>
			<br>";

        if (strpos($errMsg, $errList_2[5]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must select state!</p>";  
        } else {
          $inputClass = "correct_input";
        }
        echo "<label for='state'>State</label>
			<select name='state' id='state' required='required' class=$inputClass>" . generateStateOptions($state) . "</select>
			<br>";
          
        if (strpos($errMsg, $errList_2[6]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter postcode!</p>";  
        } else {
          if(strpos($errMsg, $errList[5]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong postcode format!</p>";
            
          } else {
            $inputClass = "correct_input";
          }
        }
        echo "<label for='pcode'>Post Code</label>
			<input type='text' name='pcode' id='pcode' required='required' value='$pcode' class='$inputClass'>
			<br>";
      
        if (strpos($errMsg, $errList_2[7]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter phone number!</p>";  
        } else {
          if(strpos($errMsg, $errList[6]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong phone number format!</p>";
            
          } else {
            $inputClass = "correct_input";
          }
        }
        echo "<label for='phone'>Phone number</label>
			<input type='text' name='phone' required='required' id='phone' maxlength='10' placeholder='012 345 6789' value='$phone' class='$inputClass'>
			<br>";

        echo "<p>Refer contact:</p>
			<label><input type='radio' name='contact' value='email' " . ($contact == 'email' ? 'checked' : '') . " required>Email</label>
			<label><input type='radio' name='contact' value='post' " . ($contact == 'post' ? 'checked' : '') . ">Post</label>
			<label><input type='radio' name='contact' value='phone' " . ($contact == 'phone' ? 'checked' : '') . ">Phone</label>
			</fieldset>
			<br>
			<br>
			<fieldset>
			<legend><h2> Class information</h2> </legend>";

        if (strpos($errMsg, $errList_2[8]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must select number of class!</p>";  
        } else {
          $inputClass = "correct_input";
        }
        echo "<label for='Quantity' >Number of class in a week</label>
			<select name='Quantity' id='Quantity' required='required' class=$inputClass>" . generateQuantityOptions($Quantity) ."</select>
			<br>";
        
        if (strpos($errMsg, $errList_2[9]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter number of week!</p>";  
        } else {
          $inputClass = "correct_input";
        }
        echo "<label for='num_week' >Number of week</label>
			<input type='number' name='num_week' id='num_week' required='required' value='$num_week' class=$inputClass>
			<br>";

        if (strpos($errMsg, $errList_2[10]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must select time to study!</p>";  
        } else {
          $inputClass = "correct_input";
        }
        echo "<label for='Option'>Choose time to study in a day</label>
			<select name='Option' id='Option' required='required' class=$inputClass>". generateOptionOptions($Option) ."</select>
			<p>Choose the subject(s) you want to focus:</p>
			<label><input type='radio' name='Product' value='dec_art'" . ($Product == 'dec_art' ? ' checked' : '') . ">Decoration art</label>
			<br>
			<label><input type='radio' name='Product' value='pen_draw'" . ($Product == 'pen_draw' ? ' checked' : '') . ">Pencil drawing</label>
			<br>
			</fieldset>
			<br>  
			<br>     
			<fieldset>
			<legend><h2>Payment information</h2></legend>
			<p class='wrong_text'>You must reselect card type!</p>
			<p>Choose your type of card</p>
			<label><input type='radio' name='CardType' value='vis_card' checked>Visa Card</label>
			<img class = 'crecard' src='images/visacard.jpg' alt='Visa Card'>
			<br>
			<label><input type='radio' name='CardType' value='mas_card'>Master Card</label>
			<img class = 'crecard' src='images/mastercard.jpg' alt='Master Card'>
			<br>  
			<label><input type='radio' name='CardType' value='ame_exp_card'>American Express Card</label>
			<img class = 'crecard' src='images/ameexpress.webp' alt='American Express Card'>
			<br>
			<br>";

        if (strpos($errMsg, $errList_2[11]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter card name!</p>";  
        } else {
          if(strpos($errMsg, $errList[7]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong card name format!</p>";
          } else {
            $inputClass = "correct_input";
            echo "<p class='wrong_text'>You must re-enter card name!</p>"; 
          }
        }
        echo "<label for='CardName'>Your name on credit card</label>
			<input type='text' name='CardName' id='CardName' class=$inputClass>
			<br>";

        if (strpos($errMsg, $errList_2[12]) !== false){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter card number!</p>";  
        } else {
          if((strpos($errMsg, $errList[10]) == false) AND (strpos($errMsg, $errList[11]) == false) AND (strpos($errMsg,   $errList[12]) == false)) { 
            $inputClass = "correct_input";
            echo "<p class='wrong_text'>You must re-enter card number!</p>"; 
          } else {
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong card number format!</p>";
          }
        }
        echo "<label for='CardNumber'>Your card number</label>
			<input type='number' name='CardNumber' id='CardNumber' class='$inputClass' >
			<br>";

        if ((strpos($errMsg, $errList_2[13]) !== false) or (strpos($errMsg, $errList_2[14]) !== false)){
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter both the month and year of card expiry date!</p>";  
        } else {
          if(strpos($errMsg, $errList[8]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong card expiry date format!</p>";
          } else {
            $inputClass = "correct_input";
            echo "<p class='wrong_text'>You must re-enter both the month and year of card expiry date!</p>";
          }
        }
        echo "<label>Your card expiry date</label>
			<input type='text' name='CardExpiryMonth' id='CardExpiryMonth' placeholder='mm' class='$inputClass'>
			<label>/</label>
			<input type='text' name='CardExpiryYear' id='CardExpiryYear' placeholder='yy' class='$inputClass'>
			<br>";

        if (strpos($errMsg, $errList_2[15]) !== false) {
          $inputClass = "wrong_input";
          echo "<p class='wrong_text'>You must enter card CVV!</p>";  
        } else {
          if(strpos($errMsg, $errList[9]) !== false){
            $inputClass = "wrong_input";
            echo "<p class='wrong_text'>Wrong card CVV format!</p>";
          } else {
            $inputClass = "correct_input";
            echo "<p class='wrong_text'>You must re-enter card CVV!</p>";  
          }
        }
        echo "<label for='CardCVV'>Your card verification value</label>
			<input type='number' name='CardCVV' id='CardCVV'  class=$inputClass>
			<br>
			</fieldset>
			<br>
			<br>
			<label for='comment'>Anything do want to share with us?</label>
			<br>
			<textarea name='comment' id='comment' class='correct_input' rows='5' cols='40'>$comment</textarea>
			</fieldset>
			<div class='buttons'>
			<input class='buttons' type='submit' value='Check Out'>
			<input class='buttons' type='reset' value='Reset form'>
			</div>
		</form>
    </main>";
    session_destroy()
  ?>

</body>
</html>
