<!DOCTYPE html>
<html lang="en">
<head>
  <title>Enroll</title>
  <meta charset="utf-8" >
  <meta name="description" content="Enquire page" >
  <meta name="keywords"    content="Assignment 1, COS10026" >
  <meta name="author"      content="Binh Ca Nguyen" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body>
  <?php 
    require_once "header.inc";
    require_once "footer.inc";
  ?>

  <main>
    <h1>Enrol in our class</h1>

    <form action="process_order.php" id="formB" method="post" novalidate>
      <fieldset id="mfield">
          <legend><h2> Please fill your information</h2></legend> 
          <label for="fnames">First Name</label>
          <input type="text" name="fnames" id="fnames" required="required">
          <br>

          <label for="lnames">Family Name</label>
          <input type="text" name="lnames" id="lnames" required="required">
          <br>

          <label for="email">Email</label>
          <input type="text" name="email" id="email" required="required">
          <br>
        
          <fieldset>
            <legend><h2> Contact information </h2> </legend>
            <label for="str_addr">Street address</label>
            <input type="text" name="str_addr" id="str_addr" required="required">
            <br>  

            <label for="sub_town">Suburb/Town</label>
            <input type="text" name="sub_town" id="sub_town" required="required">
            <br> 

            <label for="state">State</label>
            <select name="state" id="state" required="required">
              <option value="" selected="selected">Please Select</option>
              <option value="VIC">VIC</option>
              <option value="NSW">NSW</option>
              <option value="QLD">QLD</option>
              <option value="NT">NT</option>
              <option value="WA">WA</option>
              <option value="SA">SA</option>
              <option value="TAS">TAS</option>
              <option value="ACT">ACT</option>
            </select>
            <br>
            
            <label for="pcode">Post Code</label>
            <input type="text" name="pcode" id="pcode" required="required">
            <br>

            <label for="phone">Phone number</label>
            <input type="text" name="phone" required="required" id="phone" placeholder="0123456789">
            <br>

            <p>Refer contact:</p>
            <label><input type="radio" name="contact" value="email" checked required="required">Email</label>
            <label><input type="radio" name="contact" value="post">Post</label>
            <label><input type="radio" name="contact" value="phone">Phone</label>

          </fieldset>
          <br>
          <br>

          <fieldset>
            <legend><h2> Class information</h2></legend>
            <label for="Quantity">Number of class in a week</label>
            <select name="Quantity" id="Quantity" required="required">
              <option value="" selected="selected">Please Select</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
            </select>
            <br>

            <label for="num_week">Number of week</label>
            <input type="number" name="num_week" id="num_week" required="required">
            <br>

            <label for="Option">Choose time to study in a day</label>
            <select name="Option" id="Option" required="required">
              <option value="" selected="selected">Please Select</option>
              <option value="day">8:00 AM - 11:00 AM</option>
              <option value="night">6:00 PM - 9:00 PM</option>
            </select>

            <p>Choose the subject(s) you want to focus:</p>
            <label><input type="radio" name="Product" value="dec_art" checked>Decoration art</label>
            <br>
            <label><input type="radio" name="Product" value="pen_draw">Pencil drawing</label>
            <br>
            </fieldset>
            <br>
            <br>
          
            <fieldset>
              <legend><h2>Payment information</h2></legend>
              <p>Choose your type of card</p>
              <label><input type="radio" name="CardType" value="vis_card" checked>Visa Card</label>
              <img class = "crecard" src="images/visacard.jpg" alt="Visa Card">
              <br>

              <label><input type="radio" name="CardType" value="mas_card">Master Card</label>
              <img class = "crecard" src="images/mastercard.jpg" alt="Master Card">
              <br>
              
              <label><input type="radio" name="CardType" value="ame_exp_card">American Express Card</label>
              <img class = "crecard" src="images/ameexpress.webp" alt="American Express Card">
              <br>
              <br>

              <label for="CardName">Your name on credit card</label>
              <input type="text" name="CardName" id="CardName">
              <br>

              <label for="CardNumber">Your card number</label>
              <input type="number" name="CardNumber" id="CardNumber">
              <br>

              <label>Your card expiry date</label>
              <input type="text" name="CardExpiryMonth" placeholder="mm">
              <label>/</label>
              <input type="text" name="CardExpiryYear" placeholder="yy">
              <br>

              <label for="CardCVV">Your card verification value</label>
              <input type="number" name="CardCVV" id="CardCVV">
              <br>
            </fieldset>
            <br>
            <br>

            <label for="comment">Anything do want to share with us?</label>
            <br>
            <textarea name="comment" id="comment" class="box" rows="5" cols="40" placeholder="Write something"></textarea>
          </fieldset>

          <div class="buttons">
            <input class="buttons" type="submit" value="Check Out">
            <input class="buttons" type="reset" value="Reset form">
          </div>
    </form>
  </main>
  
</body>
</html>
