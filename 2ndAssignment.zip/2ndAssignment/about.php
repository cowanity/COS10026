<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Le Phan">
    <meta name="description" content="about the dev team">
    <link href="styles/style.css" rel="stylesheet" type="text/css" >
    <title>About Us</title>
</head>
<body>
    <?php 
        require_once "header.inc";
        require_once "footer.inc";
    ?>

      <main>
        <div class="info" id="Le-Phan">
            <figure class="selfie"><img src="images/Me.jpg" alt=""></figure>
            <dl class="defyList">
                <dt><strong>Name</strong></dt>
                <dd>Le Phan</dd>
    
                <dt><strong>Student ID</strong></dt>
                <dd>SWS00260</dd>
    
                <dt><strong>Course</strong></dt>
                <dd>Bachelor Of Computer Science</dd>
    
                <dt><strong>Email</strong></dt>
                <dd><a href="mailto:104212469@student.swin.edu.au">104212469@student.swin.edu.au</a></dd>
    
                <dt><strong>Hobbies</strong></dt>
                <dd>Anime, Action games, Rhythm Games, staying at home, eat, sleep</dd>
            </dl>
            <table class="timetable">
                <tr>
                    <th>TIME</th>
                    <th>MON</th>
                    <th>TUE</th>
                    <th>WED</th>
                    <th>THUR</th>
                    <th>FRI</th>
                    <th>SAT</th>
                    <th>SUN</th>
                </tr>
                <tr>
                    <td>8am-10am</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11am-2pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>3pm-7pm</td>
                    <td>TNE10006.2</td>
                    <td>VOV201.3</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>8pm-10pm</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11pm-12am</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
            </table>
        </div>
        <div class="info" id="Binh-Ca">
            <figure class="selfie"><img src="images/BinhCa.jpg" alt=""></figure>
            <dl class="defyList">
                <dt><strong>Name</strong></dt>
                <dd>Binh Ca Nguyen</dd>
    
                <dt><strong>Student ID</strong></dt>
                <dd>SWS00394</dd>
    
                <dt><strong>Course</strong></dt>
                <dd>Bachelor Of Computer Science</dd>
    
                <dt><strong>Email</strong></dt>
                <dd><a href="mailto:104225904@student.swin.edu.au">104225904@student.swin.edu.au</a></dd>
    
                <dt><strong>Hobbies</strong></dt>
                <dd>Martial Arts, Chess</dd>
            </dl>
            <table class="timetable">
                <tr>
                    <th>TIME</th>
                    <th>MON</th>
                    <th>TUE</th>
                    <th>WED</th>
                    <th>THUR</th>
                    <th>FRI</th>
                    <th>SAT</th>
                    <th>SUN</th>
                </tr>
                <tr>
                    <td>8am-10am</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11am-2pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>3pm-7pm</td>
                    <td>TNE10006.2</td>
                    <td>VOV201.3</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>8pm-10pm</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11pm-12am</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>

            </table>
        </div>
        <div class="info" id="Khoi">
            <figure class="selfie"><img src="images/Khoi.jpg" alt=""></figure>
            <dl class="defyList">
                <dt><strong>Name</strong></dt>
                <dd>Nguyen Dang Khoi</dd>
    
                <dt><strong>Student ID</strong></dt>
                <dd>SWS00293</dd>
    
                <dt><strong>Course</strong></dt>
                <dd>Bachelor Of Computer Science</dd>
    
                <dt><strong>Email</strong></dt>
                <dd><a href="mailto:104177131@student.swin.edu.au">104177131@student.swin.edu.au</a></dd>
    
                <dt><strong>Hobbies</strong></dt>
                <dd>Gamer</dd>
            </dl>
            <table class="timetable">
                <tr>
                    <th>TIME</th>
                    <th>MON</th>
                    <th>TUE</th>
                    <th>WED</th>
                    <th>THUR</th>
                    <th>FRI</th>
                    <th>SAT</th>
                    <th>SUN</th>
                </tr>
                <tr>
                    <td>8am-10am</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11am-2pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>3pm-7pm</td>
                    <td>TNE10006.2</td>
                    <td>VOV201.3</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>8pm-10pm</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11pm-12am</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>

            </table>
        </div>
        <div class="info" id="Nhan">
            <figure class="selfie"><img src="images/nhan.jpg" alt="image of Nhan"></figure>
            <dl class="defyList">
                <dt><strong>Name</strong></dt>
                <dd>Huu Nhan Le</dd>
    
                <dt><strong>Student ID</strong></dt>
                <dd>SWS00517</dd>
    
                <dt><strong>Course</strong></dt>
                <dd>Bachelor Of Computer Science</dd>
    
                <dt><strong>Email</strong></dt>
                <dd><a href="mailto:104171133@student.swin.edu.au">104171133@student.swin.edu.au</a></dd>
    
                <dt><strong>Hobbies</strong></dt>
                <dd>Playing badminton, reading books and comics</dd>
            </dl>
            <table class="timetable">
                <tr>
                    <th>TIME</th>
                    <th>MON</th>
                    <th>TUE</th>
                    <th>WED</th>
                    <th>THUR</th>
                    <th>FRI</th>
                    <th>SAT</th>
                    <th>SUN</th>
                </tr>
                <tr>
                    <td>8am-10am</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11am-2pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>JOU10007</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>3pm-7pm</td>
                    <td>TNE10006.2</td>
                    <td>VOV201.3</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>8pm-10pm</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11pm-12am</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>

            </table>
        </div>
        <div class="info" id="Phan-Vu">
            <figure class="selfie"><img src="images/phanVu.jpg" alt=""></figure>
            <dl class="defyList">
                <dt><strong>Name</strong></dt>
                <dd>Phan Vu</dd>
    
                <dt><strong>Student ID</strong></dt>
                <dd>SWS00380</dd>
    
                <dt><strong>Course</strong></dt>
                <dd>Bachelor Of Computer Science</dd>
    
                <dt><strong>Email</strong></dt>
                <dd><a href="mailto:104222099@student.swin.edu.au">104222099@student.swin.edu.au</a></dd>
    
                <dt><strong>Hobbies</strong></dt>
                <dd>Playing Piano, football, and reading books</dd>
            </dl>
            <table class="timetable">
                <tr>
                    <th>TIME</th>
                    <th>MON</th>
                    <th>TUE</th>
                    <th>WED</th>
                    <th>THUR</th>
                    <th>FRI</th>
                    <th>SAT</th>
                    <th>SUN</th>
                </tr>
                <tr>
                    <td>8am-10am</td>
                    <td>TNE10006.2</td>
                    <td>KOALA</td>
                    <td>VOV201</td>
                    <td>--EMPTY--</td>
                    <td>COS10026</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11am-2pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>KOALA</td>
                    <td>KOALA</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>3pm-7pm</td>
                    <td>TNE10006.2</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>8pm-10pm</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>
                <tr>
                    <td>11pm-12am</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                    <td>--EMPTY--</td>
                </tr>

            </table>
        </div>
      </main>
      
    </body>
</html>