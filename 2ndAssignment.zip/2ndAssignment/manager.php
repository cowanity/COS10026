<?php
//TODO IMPLEMENT CSS
//TODO IMPROVE PERF?
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="styles/style.css" rel="stylesheet" type="text/css">
    <title>Manage Orders</title>
</head>

<body>
    <?php
    require_once "header.inc";
    require_once "footer.inc";
    ?>

    <main id="manager_php">
        <form id="manager_form" method="post">
            <label for="search_type">Search By:</label><select name="search_type" id="search_bar">
                <option value="all_search">All Orders</option>
                <option value="customer_search">Customer</option>
                <option value="product_search">Product</option>
                <option value="pending_search">Pending products</option>
                <option value="cost_search">all orders, ordered by cost</option>
            </select>
            <label for="search_data">Enter search term:</label>
            <input type="text" name="search_data" id="search_data">
            <input type="submit" value="Submit">
            <input type="reset" value="Reset">

        </form>
        <br>
        <br>

        <?php
        include_once("settings.php");
        function sanitise_data($data)
        {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        if (isset($_POST['search_data'])) {
            $search_data = sanitise_data($_POST['search_data']);
            $database = mysqli_connect(
                $host,
                $user,
                $pwd,
                $sql_db
            );
            switch ($search_type = $_POST['search_type']) {
                case 'all_search':
                    $orders = mysqli_fetch_all(mysqli_query($database, "SELECT fnames, lnames, order_id, order_time, order_cost, Product, order_status FROM orders inner join customers on orders.phone = customers.phone"));
                    break;

                case 'pending_search':
                    $orders = mysqli_fetch_all(mysqli_query($database, "SELECT fnames, lnames, order_id, order_time, order_cost, Product, order_status from orders inner join customers on orders.phone = customers.phone where order_status = 'PENDING'"));;
                    break;

                case 'product_search':
                    $orders = mysqli_fetch_all(mysqli_query($database, "SELECT fnames, lnames, order_id, order_time, order_cost, Product, order_status from orders inner join customers on orders.phone = customers.phone where product = '$search_data'"));

                    break;
                case 'cost_search':
                    $orders = mysqli_fetch_all(mysqli_query($database, "SELECT fnames, lnames, order_id, order_time, order_cost, Product, order_status from orders inner join customers on orders.phone = customers.phone ORDER BY order_cost "));
                    break;
                case 'customer_search':
                    $orders = mysqli_fetch_all(mysqli_query($database, "SELECT fnames, lnames, order_id, order_time, order_cost, Product, order_status from orders inner join customers on orders.phone = customers.phone where concat (fnames, ' ', lnames) = '$search_data'"));
                    break;
            }
            echo "<table id= 'order_table'";
            echo "<tr>"
                . "<th> Order ID </th>"
                . "<th> Customer Name </th>"
                . "<th> Product Name </th>"
                . "<th> Total Cost </th>"
                . "<th> Order Time </th>"
                . "<th> Status </th>"
                . "<th> Action </th>"
                . "</tr>";
            for ($i = 0; $i < count($orders); $i++) {
                echo "<tr>";
                echo "<td>", $orders[$i][2], "</td>"; //ID
                echo "<td>", $orders[$i][0] . ' ' . $orders[$i][1], "</td>"; //Name
                echo "<td>", $orders[$i][5], "</td>"; //Product
                echo "<td>", $orders[$i][4], "</td>"; //cost
                echo "<td>", $orders[$i][3], "</td>"; //time
                echo "<td>", $orders[$i][6], "</td>"; //status
                if ($orders[$i][6] == 'PENDING') {
                    echo "<td>", "<form name = 'delete_order' action = 'deleteorder.php' method = 'post'>"; //action
                    echo "<input type='hidden' name='orderID' value =", $orders[$i][2], "/>";
                    echo "<input type='submit' name='delete_order' value = 'Delete'/>";
                    echo "</form></td>";
                    echo "<td>", "<form name = 'update_order' action = 'updateorder.php' method = 'post'>"; //action
                    echo "<input type='hidden' name='orderID' value =", $orders[$i][2], "/>";
                    echo "<select name = 'updateStatus'>";
                    echo "<option value = 'FULFILLED'>FULFILLED</option>";
                    echo "<option value = 'PENDING'>PENDING</option>";
                    echo "<option value = 'ARCHIVED'>ARCHIVED</option>";
                    echo "<option value = 'PAID'>PAID</option>";
                    echo "<input type='submit' name='update_order' value = 'Update'/>";
                    echo "</form></td>";
                } else {
                    echo "<td>", "<form name = 'update_order' action = 'updateorder.php' method = 'post'>"; //action
                    echo "<input type='hidden' name='orderID' value =", $orders[$i][2], "/>";
                    echo "<select name = 'updateStatus'>";
                    echo "<option value = 'FULFILLED'>FULFILLED</option>";
                    echo "<option value = 'PENDING'>PENDING</option>";
                    echo "<option value = 'ARCHIVED'>ARCHIVED</option>";
                    echo "<option value = 'PAID'>PAID</option>";
                    echo "<input type='submit' name='update_order' value = 'Update'/>";
                    echo "</form></td>";
                }
            }
        }
        ?>
    </main>
</body>

</html>