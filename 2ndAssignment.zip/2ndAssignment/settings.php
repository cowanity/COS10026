<?php 
 $host = "feenix-mariadb.swin.edu.au";
 $user = "s104225904";
 $pwd = "200304"; 
 $sql_db = "s104225904_db"; 
?>