<!DOCTYPE html>
<html lang="en">
<head>
  <title>Information</title>
  <meta charset="utf-8" >
  <meta name="description" content="Product page" >
  <meta name="keywords"    content="Assignment Part 2, COS10026" >
  <meta name="author"      content="Vu Phan, Huu Nhan Le (enhancements Assignment 2)" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body>
    <?php 
        
        require_once "header.inc";
        require_once "footer.inc";
        require_once "settings.php";
        $conn = @mysqli_connect($host,
            $user, 
            $pwd, 
            $sql_db);
        
        if (!$conn) {
          echo "<br><br><br><p>Database connection failure</p>";
        } else {
          $sql_table="products";

          
          $query = 'select Quantity, Options, Price FROM products WHERE Product = "dec_art"';
                
          $result = mysqli_query($conn, $query);
    
          if(!$result) {
            echo "<br><br><br><p>Something is wrong with ", $query, "</p>";
          } else {

            $Quantity_1 = array();
            $Options_1 = array ();
            $Price_1 = array();

            $index_1 = 0;
            while ($row = mysqli_fetch_assoc($result)) {
              array_push($Quantity_1, $row["Quantity"]);
              array_push($Options_1, $row["Options"]);
              array_push($Price_1, $row["Price"]);
              $index_1++;
            }

            mysqli_free_result ($result);
            $row = Null;
          }
          
          $query = 'select Quantity, Options, Price FROM products WHERE Product = "pen_draw"';
                
          $result = mysqli_query($conn, $query);
      
          if(!$result) {
            echo "<br><br><br><p>Something is wrong with ", $query, "</p>";
          } else {
  
            $Quantity_2 = array();
            $Options_2 = array ();
            $Price_2 = array();
  
            $index_2 = 0;
            while ($row = mysqli_fetch_assoc($result)) {
              array_push($Quantity_2, $row["Quantity"]);
              array_push($Options_2, $row["Options"]);
              array_push($Price_2, $row["Price"]);
              $index_2++;
            }

            mysqli_free_result ($result);
            $row = Null;
          }
          mysqli_close($conn);
        }
            
    ?>
		
  <div id="as1">
    <aside>
      <fieldset>
        <legend>Index</legend>
        <ol>
          <li><a class="index" href="#classinfo">What is MeArt?</a></li>
          <li><a class="index" href="#lecinfo">Lecturer's information</a></li>
          <li><a class="index" href="#classroom">Classroom's images</a></li>
          <li><a class="index" href="#decoration_art">Decoration Art classes</a></li>
          <li><a class="index" href="#pencil_drawing">Pencil Drawing classes</a></li>
          <li><a class="index" href="#reason">Why choose us?</a></li>
        </ol>
      </fieldset>
    </aside>
  </div>  
              
  <main id="information">
    
  <section id="classinfo" class="sec">
    <fieldset>
      <legend><h2>What is MeArt?</h2></legend>
      <p>MeArt is a drawing class that was established by Mr. Nguyen Van Hao at his house. Our main aim is to prepare essential drawing skills for learners who want to enroll in art majors at various universities. However, people who are just simply fond of art or drawing can also enroll in our class, and we will have a different curriculum for this kind of people.</p>
    </fieldset>
  </section>



    <section class="sec" >
      <fieldset>
        <legend><h2>Our lecturers</h2></legend>
        <br>
        <table id="lecinfo">
          <tr id="tab">
            <td><img class="teacher" src="images/lecturer.jpg" alt="lecturer"></td>
            <td><img class="teacher" src="images/assistant.jpg" alt="assisstant"></td>
          </tr>

          <tr>
            <td>
              <h5>Lecturer at MeArt</h5>
              <p>Mr. Nguyen Van Hao. Born: 1965.</p> 
              <p>Lecture at Van Lang Univercity. Bachelor’s Industrial Design degree. Also, he is graphic designer with more than 20 years experence.</p>
            </td>
            <td>
              <h5>Assistant at MeArt</h5>
              <p>Mr. Nguyen Cung Dan. Born: 1996. </p>
              <p>Bachelor’s Graphic Design degree at Ton Duc Thang University. Master's Applied Art degree. He has 4 years experence in graphic design.</p>
            </td>
          </tr>                
        </table>
      </fieldset>   
    </section>


    <section class="sec" >
      <fieldset>
        <legend><h2>Facility and equipments</h2></legend>
        <p>Comfortable classroom is one of unique feature we're pround of. Instead of using a room with a large amount of tables and chairs as casual classs, we use living room, dining room, and gargare of our home as a classroom to bring the best experience for leanrers, make them feel like this is their second home.</p>
        <table id="classroom">
          <tr>
            <td><embed src="images/class1.jpg" alt="class" class="cr"></td>
            <td><embed src="images/class2.jpg" alt="class" class="cr"></td>
            <td><embed src="images/class3.jpg" alt="class" class="cr"></td>
          </tr>

          <tr>
            <td><embed src="images/class4.jpg" alt="class" class="cr"></td>
            <td><embed src="images/class5.jpg" alt="class" class="cr"></td>
            <td><embed src="images/class6.jpg" alt="class" class="cr"></td>
          </tr>
        </table>
      </fieldset>  
    </section>

    <section class="sec" id="decoration_art">
      <fieldset>
          <legend><h2>Decoration Art</h2></legend>
          <div class="ProductDescription">
            <figure class="ProductImage">
                <embed src="images/Art_Decoration_1.jpg">
                <embed src="images/Art_Decoration_2.jpg">
            </figure>
            <p>Decorative art is a subject that create decorative partern that are often stylized motifs from images found in nature and life. Animals in the water, on land, and in the air are used to create textures. Textures are made from various objects, such as kitchenware and school supplies.</p>
          </div>
          <?php 
            $count_1 = 0;
            while ($count_1 < count($Options_1)) {
              switch ($Options_1[$count_1]) {
                case "day":
                    $Options_1[$count_1] = "8:00 AM - 11:00 AM";
                    break;
                case "night":
                    $Options_1[$count_1] = "6:00 PM - 9:00 PM";
                    break;
              }
              $count_1++;
            }

            $count_2 = 0;
            while ($count_2 < count($Quantity_1)) {
              if ($Quantity_1 != 1) {
                $Quantity_1[$count_2] = $Quantity_1[$count_2] . " classes";
              } else {
                $Quantity_1[$count_2] = $Quantity_1[$count_2] . " class";
              }
              $count_2++;
            }

            echo "<table class='ProductTable'>";
              echo "<tr>";
                echo "<th class='QuantityColumn'>Classes per week</th>";
                echo "<th class='OptionsColumn'>Class schedule</th>";
                echo "<th class='PriceColumn'>Price per week</th>";
              echo "</tr>";

              $index_1 = 0;
              while ($index_1 < count($Quantity_1)) {
                echo "<tr>";
                  echo "<td class='QuantityColumn'>$Quantity_1[$index_1]</td>";
                  echo "<td class='OptionsColumn'>$Options_1[$index_1]</td>";
                  echo "<td class='PriceColumn'>$Price_1[$index_1] VND</td>";
                echo "</tr>";
                $index_1++;
              }
            echo "</table>";
          ?>

      </fieldset>
    </section>

    <section class="sec" id="pencil_drawing">
      <fieldset>
          <legend><h2>Pencil Drawing</h2></legend>
          <div class="ProductDescription">
            <figure class="ProductImage">
                <embed src="images/Pencil_Drawing_1.jpg">
                <embed src="images/Pencil_Drawing_2.jpg">
            </figure>
            <p>Pencil drawing is a subject that describes real objective objects that our eyes can observe by lines, shapes, arrays, blocks, light and dark, dark and light to create the illusion of a three-dimensional space on a two-dimensional surface.</p>
          </div>
          <?php 
            $count_1 = 0;
            while ($count_1 < count($Options_2)) {
              switch ($Options_2[$count_1]) {
                case "day":
                    $Options_2[$count_1] = "8:00 AM - 11:00 AM";
                    break;
                case "night":
                    $Options_2[$count_1] = "6:00 PM - 9:00 PM";
                    break;
              }
              $count_1++;
            }

            $count_2 = 0;
            while ($count_2 < count($Quantity_2)) {
              if ($Quantity_2 != 1) {
                $Quantity_2[$count_2] = $Quantity_2[$count_2] . " classes";
              } else {
                $Quantity_2[$count_2] = $Quantity_2[$count_2] . " class";
              }
              $count_2++;
            }

            echo "<table class='ProductTable'>";
              echo "<tr>";
                echo "<th class='QuantityColumn'>Classes per week</th>";
                echo "<th class='OptionsColumn'>Class schedule</th>";
                echo "<th class='PriceColumn'>Price per week</th>";
              echo "</tr>";

              $index_1 = 0;
              while ($index_1 < count($Quantity_2)) {
                echo "<tr>";
                  echo "<td class='QuantityColumn'>$Quantity_2[$index_1]</td>";
                  echo "<td class='OptionsColumn'>$Options_2[$index_1]</td>";
                  echo "<td class='PriceColumn'>$Price_2[$index_1] VND</td>";
                echo "</tr>";
                $index_1++;
              }
            echo "</table>";       
          ?>
      </fieldset>
    </section>

    <section class="sec" id="reason">
      <fieldset>
        <legend><h2>Why you should choose us</h2></legend>
        <p>In conclusion, there are reasons why you as path to art major at universities (or just simply like drawing)?</p>
        <ul>
          <li>Experienced lecturer</li>  
          <li>Comfortable classroom</li>
          <li>We care about quality</li>
        </ul>
      </fieldset>
    </section>

      
     
  </main>           
</body>
</html>
