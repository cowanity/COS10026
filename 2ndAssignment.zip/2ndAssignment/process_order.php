<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing Orders</title>
</head>

<body>
    <?php
    include_once('settings.php');
    function sanitise_data($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    if (!isset($_POST["fnames"])) {
        header('location: payment.php');
        exit;
    }
    $errMsg = "";
    foreach ($_POST as $key => $value) { //checks, grabs, cleans, and push all post data into sessions
        ${$key} = $value;
        sanitise_data(${$key});
        unset($Submit);
        $_SESSION["$key"] = $value;
        unset($_SESSION["Submit"]);
        if (!$value && $key != 'comment') {
            $errMsg .= "no $key data";
            $_SESSION['Error'] = $errMsg;
        }
    } { //verify info
        if (!preg_match("/^[a-zA-Z-' ]*$/", $fnames)) {
            $errMsg .= "fnames ";
        }
        if (!preg_match("/^([a-zA-Z-' ]|\d){0,20}$/", $fnames)) {
            $errMsg .= "sub_town ";
        }
        if (!preg_match("/^([a-zA-Z-' ]|\d){0,40}$/", $fnames)) {
            $errMsg .= "str_addr ";
        }
        if (!preg_match("/^[a-zA-Z-' ]*$/", $lnames)) {
            $errMsg .= "lnames ";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errMsg .= "email ";
        }
        if (!preg_match("/^0\d{9}$/", $phone)) {
            $errMsg .= "phone ";
        }
        switch ($state) { // cross check post code and state
            case 'VIC':
                if (!preg_match("/^3\d{3}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;

            case 'NSW':
                if (!preg_match("/^2[0-5]\d{2}$|^2619$|^2[6-8][2-9]\d$|^2[7-8]\d{2}$|^29[2-9][1-9]$|^2[9][3-9]0$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'QLD':
                if (!preg_match("/^4\d{3}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'NT':
                if (!preg_match("/^08\d{2}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'WA':
                if (!preg_match("/^6[0-7]\d[0-7]$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'SA':
                if (!preg_match("/^5[0-7]\d{2}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'TAS':
                if (!preg_match("/^7[0-7]\d{2}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case 'ACT':
                if (!preg_match("/^3\d{3}$/", $pcode)) {
                    $errMsg .= "pcode ";
                }
                break;
            case '':
                $errMsg .= "pcode ";
        }
    } { //verify card
        switch ($CardType) {
            case 'vis_card':
                if (!preg_match("/^4\d{15}$/", $CardNumber)) {
                    $errMsg .= 'Wrong Visa format ';
                }
                break;
            case 'mas_card':
                if (!preg_match("/^5[1-5]\d{14}$/", $CardNumber)) {
                    $errMsg .= 'Wrong Mastercard format ';
                }
                break;
            case 'ame_exp_card':
                if (!preg_match("/^3[4-7]\d{13}$/", $CardNumber)) {
                    $errMsg .= 'Wrong AmericanExpress format ';
                }
                break;
        }
        if (!preg_match("/^[a-zA-Z-' ]*$/", $CardName)) {
            $errMsg .= "CardName ";
        }
        if (!preg_match("/^\d{3}$/", $CardCVV)) {
            $errMsg .= 'CardCVV ';
        }
        if (!preg_match("/^(0?[1-9]|1[012])$/", $CardExpiryMonth)) {
            $errMsg .= 'Card Expired! ';
        }
        if (!preg_match("/^\d{2}$|^20\d{2}$/", $CardExpiryYear)) {
            $errMsg .= 'Card Expired! ';
        }
        $currentYear = substr(date("Y"), 2);
        $currentMonth = date("m");
        $CardExpiry = date('Y-m-t', strtotime(substr_replace($CardExpiryYear, '20', 0, 0) . '-' . $CardExpiryMonth));
        if ($CardExpiryYear < $currentYear) {
            $errMsg .= 'Card Expired! ';
        }
        if ($CardExpiryYear == $currentYear) {
            if ($CardExpiryMonth < $currentMonth) {
                $errMsg .= 'Card Expired! ';
            }
        }
        if ($errMsg != "") {
            $_SESSION["Error"] = $errMsg;
            header('location: fix_order.php');
            exit;
        }
    } { //Get price from database and calc total
        $PriceGet = "SELECT Price FROM products WHERE Product = '$Product' AND Options = '$Option' AND Quantity = '$Quantity' ";
        $Database = mysqli_connect("$host", "$user", "$pwd", "$sql_db");
        if (!$Database) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $Price = (int)mysqli_fetch_assoc(mysqli_query($Database, $PriceGet))['Price'];
        $order_cost = $Price * $num_week;
    } { //push data into database 
        $date = date("y/m/d");
        $comment = mysqli_real_escape_string($Database, $comment);

        //?query strings
        $GetPhone = "SELECT phone FROM customers WHERE phone = '$phone' ";
        $NoOrders = "CREATE TABLE IF NOT EXISTS orders ( 
            order_id INT AUTO_INCREMENT PRIMARY KEY,
            Quantity int ,
            Product varchar(255),
            Price int(11),
            Options ENUM ('day' , 'night'),
            comment varchar(255),
            phone varchar(10),
            pcode varchar (5),
            num_week int(5),
            contact varchar(20),
            order_cost INT, 
            order_time DATE,
            order_status ENUM('PENDING','FULFILLED','PAID','ARCHIVED') default 'PENDING')";
        $NoInfo = "CREATE TABLE IF NOT EXISTS customers (
             fnames varchar(25) ,
             lnames varchar(25) ,
             email  varchar(255) ,
             phone varchar(10) primary key ,
             state varchar(4),
             str_addr varchar(40) ,
             sub_town varchar(40) ,
             CardType varchar(255) ,
             CardName  varchar(255) ,
             CardNumber varchar(255) ,
             CardExpiry date ,
             CardCVV int )";
        $insertOrder = "INSERT INTO orders (order_cost, order_time, phone, Quantity, Product, Price, Options, comment, pcode, num_week, contact) VALUES ('$order_cost','$date', '$phone', '$Quantity', '$Product', '$Price', '$Option', '$comment' , '$pcode', '$num_week', '$contact')";
        $insertCustomer = "INSERT INTO customers ( fnames, lnames, email, phone, state, str_addr, sub_town, CardType, CardName, CardNumber, CardExpiry, CardCVV) VALUES ('$fnames','$lnames','$email','$phone', '$state', '$str_addr', '$sub_town', '$CardType', '$CardName', '$CardNumber', '$CardExpiry', '$CardCVV')";
        // check/create table and insert data
        mysqli_query($Database, $NoInfo);
        mysqli_query($Database, $NoOrders);
        mysqli_query($Database, $insertOrder);
        $CheckPhone = mysqli_fetch_assoc(mysqli_query($Database, $GetPhone));
        if (empty($CheckPhone['phone'])) {
            mysqli_query($Database, $insertCustomer);
        }
    }
    header('location: receipt.php');
    exit;
    ?>
</body>

</html>