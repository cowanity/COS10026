<!DOCTYPE html>
<html lang="en">
<head>
  <title>Enroll</title>
  <meta charset="utf-8" >
  <meta name="description" content="Enquire page" >
  <meta name="keywords"    content="Assignment 1, COS10026" >
  <meta name="author"      content="Binh Ca Nguyen" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body>
    <?php 
        require_once "header.inc";
        require_once "footer.inc";
    ?>

    <main>
      <h1>Enrol in our class</h1>

      <form action="https://mercury.swin.edu.au/it000000/formtest.php" id="form" method="post">
        <fieldset id="mfield">

          <legend>Please fill your information</legend> 
          <label for="fname">First Name</label>
          <input type="text" name="fname" id="fname" required="required" maxlength="25" pattern="^[a-zA-Z ]+$">
          <br>

          <label for="faminame">Family Name</label>
          <input type="text" name="faminame" id="faminame" required="required" maxlength="25" pattern="^[a-zA-Z ]+$">
          <br>

          <label for="email">Email</label>
          <input type="text" name="email" id="email" required="required">
          <br>
        
        
          <fieldset>
            <legend>Address</legend>
            <label for="straddress">Street address</label>
            <input type="text" name="straddress" id="straddress" required="required" maxlength="40">
            <br>  

            <label for="sutown">Suburb/Town</label>
            <input type="text" name="sutown" id="sutown" required="required" maxlength="40">
            <br> 

            <label for="state">State</label>
            <select name="state" id="state" required="required">
              <option value="" selected="selected">Please Select</option>
              <option value="VIC">VIC</option>
              <option value="NSW">NSW</option>
              <option value="QLD">QLD</option>
              <option value="NT">NT</option>
              <option value="WA">WA</option>
              <option value="SA">SA</option>
              <option value="TAS">TAS</option>
              <option value="ACT">ACT</option>
            </select>
            <br>
            
            <label for="zcode">Zip Code</label>
            <input type="text" name="zcode" id="zcode" required="required" pattern="[0-9]{4}">
            <br>

          </fieldset>

          <label for="phnumber">Phone number</label>
          <input type="text" name="phnumber" required="required" id="phnumber" maxlength="10" placeholder="012 345 6789" pattern="[0-9]{0,10}">
          <br>

          <p>Refer contact:</p>
          <label><input type="radio" name="contact" value="email" checked required="required">Email</label>
          <label><input type="radio" name="contact" value="post">Post</label>
          <label><input type="radio" name="contact" value="phone">Phone</label>


          <br>
          <label for="dayclass">Which class do you want to participate in?</label>
          <select name="dayclass" id="dayclass"  required="required">
            <option value="" selected="selected">Please select</option>
            <option value="246">Monday, Wednesday, and Friday</option>
            <option value="357">Tuesday, Thursday, and Saturday</option>
          </select>
          <br>
          <br>

          <p>Choose the subject(s) you want to focus:</p>
          <label><input type="checkbox" name="subject[]" value="Decor">Decoration art</label>
          <label><input type="checkbox" name="subject[]" value="Draw">Pencil drawing</label>
          <br>
          <br>

          <label for="comment">Anything do want to share with us?</label>
          <br>
          <textarea name="comment" id="comment" class="box" rows="5" cols="40" placeholder="Write something"></textarea>

        </fieldset>

        <div class="buttons">
          <input class="buttons" type="submit" name="Submit">
          <input class="buttons" type="reset" name="Reset form">
        </div>
      </form>
    </main>

    <br>
    <br>        
</body>
</html>
