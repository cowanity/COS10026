<?php
include_once('settings.php');
$Database = mysqli_connect($host, $user, $pwd, $sql_db);
$order_id = $_POST["orderID"];
$query = "DELETE FROM orders WHERE order_id ='$order_id'";
$result = mysqli_query($Database, $query);
header("location: manager.php");
exit;
