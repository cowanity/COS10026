<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Receipt</title>
  <meta charset="utf-8" >
  <meta name="description" content="Receipt page" >
  <meta name="keywords"    content="Assignment Part 2, COS10026" >
  <meta name="author"      content="Huu Nhan Le (104171133)" >
  <link href="styles/style.css" rel="stylesheet" type="text/css" >
</head>
<body>
    <?php 
         if (!isset($_SESSION["phone"])) {
            header("location: payment.php");
            exit;
        } 

        require_once "header.inc";
        require_once "footer.inc";
        require_once "settings.php";

        $phone = $_SESSION["phone"];

        $conn = @mysqli_connect($host,
            $user, 
            $pwd, 
            $sql_db);
        
		if (!$conn) {
			echo "<br><br><br><p>Database connection failure</p>";
		} else {
			$sql_table="customers";

			$query = 'select fnames, lnames, email, str_addr, sub_town, state, phone, CardType, CardName, CardNumber, CardExpiry, CardCVV FROM customers WHERE phone = "' . $phone . '" ';
			
			$result = mysqli_query($conn, $query);

			if(!$result) {
				echo "<br><br><br><p>Something is wrong with ", $query, "</p>";
			} else {
				$row = mysqli_fetch_assoc($result);
				
				$fnames = $row["fnames"];
				$lnames = $row["lnames"];
				$email = $row["email"];
				$str_addr = $row["str_addr"];
				$sub_town = $row["sub_town"];
				$state = $row["state"];
				$phone = $row["phone"];

				$CardType = $row["CardType"];
				$CardName = $row["CardName"];
				$CardNumber = $row["CardNumber"];
				$CardExpiry = $row["CardExpiry"];
				$CardCVV = $row["CardCVV"];

				mysqli_free_result ($result);
				$query = null;
				$result = null; 
			}

			$sql_table="orders";

			$query = 'select MAX(order_id) from orders WHERE phone = "' . $phone . '" ';
			
			$result = mysqli_query($conn, $query);

			if(!$result) {
				echo "<br><br><br><p>Something is wrong with ", $query, "</p>";
			} else {
				$row = mysqli_fetch_assoc($result);

				$order_id = $row["MAX(order_id)"];
				mysqli_free_result ($result);
			}

			$query = 'select order_id, order_cost, order_time, order_status, Product, Quantity, num_week, Options, comment, Price, pcode, contact from orders WHERE (order_id = "' . $order_id . '") ';
			
			$result = mysqli_query($conn, $query);

			if(!$result) {
				echo "<br><br><br><p>Something is wrong with ", $query, "</p>";
			} else {
				$row = mysqli_fetch_assoc($result);

				$order_cost = $row["order_cost"];
				$order_time = $row["order_time"];
				$order_status = $row["order_status"];

				$Product= $row["Product"];
				$Quantity = $row["Quantity"];
				$num_week = $row["num_week"];
				$Options = $row["Options"];
				$comment = $row["comment"];
				$Price = $row["Price"];

				$pcode = $row["pcode"];
				$contact = $row["contact"];

				mysqli_free_result ($result);
			}                
			mysqli_close($conn);
		}
    ?>

    <main>
    
        <h1>Thank you for using our service</h1>
        <br>
        <div id="receipt_php">

            <div id="receipt_sections">
                <section id="custom_info">
                    <h2>Customer Details</h2>
                    <hr>
                    <?php 
                        switch ($state) {
                            case "VIC":
                                $state = "Victoria";
                                break;
                            case "NSW":
                                $state = "New South Wales";
                                break;
                            case "QLD":
                                $state = "Queensland";
                                break;
                            case "NT";
                                $state = "Northern Territory";
                                break;
                            case "WA";
                                $state = "Western Australia";
                                break;
                            case "SA";
                                $state = "South Australia";
                                break;
                            case "TAS";
                                $state = "Tasmania";
                                break;
                            case "ACT";
                                $state = "Australian Capital Territory";
                                break;
                        }

                        switch ($contact) {
                            case "email":
                                $contact = "Email";
                                break;
                            case "post":
                                $contact = "Post";
                                break;
                            case "phone":
                                $contact = "Phone";
                                break;
                        }

                        echo "<p>Name: <strong>". $fnames ." " . $lnames . "</strong></p><hr>";
                        echo "<p>Email: <strong>$email</strong></p><hr>";
                        echo "<p>Address: <strong>$str_addr, $sub_town, $state</strong> (Postcode: <strong>$pcode</strong>)</p><hr>";
                        echo "<p>Phone number: <strong>$phone</strong></p><hr>";
                        echo "<p>Preferred contact: <strong>$contact</strong></p>"
                    ?>
                </section>
            
            
                <section id="credit_info">
                    <h2>Credit Card Details</h2>
                    <hr>
                    <?php 
                        switch ($CardType) {
                            case "vis_card":
                                $CardType = "Visa Card";
                                break;
                            case "mas_card":
                                $CardType = "Mastercard";
                                break;
                            case "ame_exp_card":
                                $state = "American Express Card";
                                break;
                        }

                        echo "<p>Card type: <input type='password' class='secure' value='$CardType' readonly>";
                        $hidden = preg_replace("|.|","*",$CardType);
                        echo "<strong>$hidden</strong></p><hr>";
                        echo "<p>Card name: <input type='password' class='secure' value='$CardName' readonly>";
                        $hidden = preg_replace("|.|","*",$CardName);
                        echo "<strong>$hidden</strong></p><hr>";
                        echo "<p>Card number: <input type='password' class='secure' value='$CardNumber' readonly>";
                        $hidden = preg_replace("|.|","*",$CardNumber);
                        echo "<strong>$hidden</strong></p><hr>";
                        echo "<p>Card expiry date: <input type='password' class='secure' value='$CardExpiry' readonly>";
                        $hidden = preg_replace("|.|","*",$CardExpiry);
                        echo "<strong>$hidden</strong></p><hr>";
                        echo "<p>Card CVV: <input type='password' class='secure' value='$CardCVV' readonly>";
                        $hidden = preg_replace("|.|","*",$CardCVV);
                        echo "<strong>$hidden</strong></p>";
                    ?>
                </section>
            </div>
            <br>
            
            <section id="product_info">
                <h2>Service Details</h2>
                <hr>
                <?php
                    switch ($Product) {
                        case "dec_art":
                            $Product = "Decoration art";
                            $Product_Image ="images/Art_Decoration_1.jpg";
                            break;
                        case "pen_draw":
                            $Product = "Pencil Drawing";
                            $Product_Image ="images/Pencil_Drawing_1.jpg";
                            break;
                    }

                    switch ($Options) {
                        case "day":
                            $Options = "8:00 AM - 11:00 AM";
                            break;
                        case "night":
                            $Options = "6:00 PM - 9:00 PM";
                            break;
                    }

                    if ($Quantity != 1) {
                        $Quantity = $Quantity . " classes";
                    } else {
                        $Quantity = $Quantity . " class";
                    }

                    if ($num_week != 1) {
                        $num_week = $num_week . " weeks";
                    } else {
                        $num_week = $num_week . " week";
                    }
                    echo "<div id='Order_row'>";
                    echo "<p id='OrderIndex'>Order ID: <strong>$order_id</strong></p>";
                    echo "<p id='OrderTime'>Order time: <strong>$order_time</strong></p>";
                    echo "<p id='OrderStatus'>Order status: <strong>$order_status</strong></p></div><hr>";

                    echo "<table id='OrderInfo'>";
                        echo "<tr><th class='IndexColumn'>Index</th>";
                        echo "<th class='ProductColumn'>Subject</th>";
                        echo "<th class='OptionsColumn'>Class schedule</th>";
                        echo "<th class='QuantityColumn'>Classes per week</th>";
                        echo "<th class='num_weekColumn'>Number of weeks</th>";
                        echo "<th class='commentColumn'>Note</th>";
                        echo "<th class='PriceColumn'>Price per week</th>";
                        echo "</tr>";

                        echo "<tr>";
                        echo "<td class='IndexColumn'>1</td>";
                        echo "<td class='ProductColumn'>$Product<br><embed src='$Product_Image'></td>";
                        echo "<td class='OptionsColumn'>$Options</td>";
                        echo "<td class='QuantityColumn'>$Quantity</td>";
                        echo "<td class='num_weekColumn'>$num_week</td>";
                        echo "<td class='commentColumn'>$comment</td>";
                        echo "<td class='PriceColumn'>$Price VND</td>";
                        echo "</tr>";

                        $row_number = 5;
                        $count_number_3 = 1;
                        if ($count_number_3 < $row_number ) {
                            while ($count_number_3 < $row_number) {
                                $count_number_2 = ($count_number_3 + 1);
                                echo "<tr>";
                                echo "<td class='IndexColumn'>$count_number_2</td>";
                                echo "<td class='ProductColumn'></td>";
                                echo "<td class='OptionsColumn'></td>";
                                echo "<td class='QuantityColumn'></td>";
                                echo "<td class='num_weekColumn'></td>";
                                echo "<td class='commentColumn'></td>";
                                echo "<td class='PriceColumn'></td>";
                                echo "</tr>";
                                $count_number_3++;
                            }
                        }

                        echo "<tr>";
                        echo "<td class='SpecialCell' colspan='6'><strong>Total Cost:</strong></td>";
                        echo "<td class='PriceColumn'>$order_cost VND</td>";
                        echo "</tr>";

                    echo "</table>";
                    session_destroy();
                ?>
            </section>
        </div> 
    </main>
    <br>
</body>
</html>